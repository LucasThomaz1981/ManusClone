import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";

// Pages
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Tasks from "@/pages/Tasks";
import Templates from "@/pages/Templates";
import Settings from "@/pages/Settings";
import BitcoinRecovery from "@/pages/BitcoinRecovery";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  // Handle template prompts from session storage
  useEffect(() => {
    const handleTemplatePrompt = (event: CustomEvent) => {
      const prompt = event.detail;
      // This will be handled by the ChatInterface component
      const chatInput = document.querySelector('[data-testid="chat-input"]') as HTMLTextAreaElement;
      if (chatInput) {
        chatInput.value = prompt;
        chatInput.focus();
        // Trigger the send button click
        const sendButton = document.querySelector('[data-testid="button-send"]') as HTMLButtonElement;
        sendButton?.click();
      }
    };

    window.addEventListener('useTemplatePrompt', handleTemplatePrompt as EventListener);
    return () => {
      window.removeEventListener('useTemplatePrompt', handleTemplatePrompt as EventListener);
    };
  }, []);

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/tasks" component={Tasks} />
          <Route path="/templates" component={Templates} />
          <Route path="/settings" component={Settings} />
          <Route path="/bitcoin-recovery" component={BitcoinRecovery} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
