import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Template } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, TrendingUp, Globe, ChartPie, FileText, Database, Code } from "lucide-react";

const iconMap = {
  'trending-up': TrendingUp,
  'globe': Globe,
  'presentation-chart': ChartPie,
  'file-text': FileText,
  'database': Database,
  'code': Code,
  'search': Search,
};

interface TemplateGalleryProps {
  onSelectTemplate: (template: Template) => void;
}

export function TemplateGallery({ onSelectTemplate }: TemplateGalleryProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: templates = [], isLoading } = useQuery<Template[]>({
    queryKey: ['/api/templates'],
  });

  // Mock templates for demonstration since we don't have seeded data
  const mockTemplates: Template[] = [
    {
      id: '1',
      name: 'Stock Analysis Report',
      description: 'Comprehensive stock analysis with charts and recommendations',
      category: 'Finance',
      prompt: 'Analyze {STOCK_SYMBOL} stock performance over the last 12 months, including technical analysis, fundamental metrics, and investment recommendations.',
      icon: 'trending-up',
      color: 'blue',
      estimatedCredits: 150,
      createdAt: new Date(),
    },
    {
      id: '2', 
      name: 'Personal Website Builder',
      description: 'Create a responsive portfolio website',
      category: 'Web Development',
      prompt: 'Build a professional portfolio website for {PROFESSION} with modern design, responsive layout, and interactive elements.',
      icon: 'globe',
      color: 'green',
      estimatedCredits: 200,
      createdAt: new Date(),
    },
    {
      id: '3',
      name: 'Business Presentation',
      description: 'Professional slide deck with data visualizations',
      category: 'Business',
      prompt: 'Create a comprehensive business presentation about {TOPIC} with executive summary, market analysis, and actionable recommendations.',
      icon: 'presentation-chart',
      color: 'purple',
      estimatedCredits: 120,
      createdAt: new Date(),
    },
    {
      id: '4',
      name: 'Market Research Report',
      description: 'In-depth market analysis and competitive landscape',
      category: 'Research',
      prompt: 'Conduct thorough market research on {INDUSTRY} including market size, key players, trends, and growth opportunities.',
      icon: 'search',
      color: 'orange',
      estimatedCredits: 180,
      createdAt: new Date(),
    },
    {
      id: '5',
      name: 'Data Visualization Dashboard',
      description: 'Interactive charts and analytics dashboard',
      category: 'Data Analytics',
      prompt: 'Create an interactive data dashboard for {DATA_TYPE} with multiple chart types, filters, and insights.',
      icon: 'database',
      color: 'indigo',
      estimatedCredits: 160,
      createdAt: new Date(),
    },
    {
      id: '6',
      name: 'Code Review & Documentation',
      description: 'Analyze code and generate technical documentation',
      category: 'Development',
      prompt: 'Review the provided codebase and generate comprehensive technical documentation including API docs, code comments, and architecture overview.',
      icon: 'code',
      color: 'gray',
      estimatedCredits: 100,
      createdAt: new Date(),
    },
  ];

  const displayTemplates = templates.length > 0 ? templates : mockTemplates;

  const filteredTemplates = displayTemplates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (template.description || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = Array.from(new Set(displayTemplates.map(t => t.category)));

  const getColorClass = (color: string) => {
    const colorMap: Record<string, string> = {
      blue: 'from-blue-500 to-blue-600',
      green: 'from-green-500 to-green-600',
      purple: 'from-purple-500 to-purple-600',
      orange: 'from-orange-500 to-orange-600',
      indigo: 'from-indigo-500 to-indigo-600',
      gray: 'from-gray-500 to-gray-600',
    };
    return colorMap[color] || 'from-primary to-accent';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6" data-testid="template-gallery">
      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="search-templates"
          />
        </div>
        
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedCategory === null ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(null)}
            data-testid="category-all"
          >
            All Categories
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              data-testid={`category-${category.toLowerCase().replace(' ', '-')}`}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Template Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => {
          const Icon = iconMap[template.icon as keyof typeof iconMap] || FileText;
          
          return (
            <Card key={template.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${getColorClass(template.color)} flex items-center justify-center`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {template.estimatedCredits} credits
                  </Badge>
                </div>
                <CardTitle className="text-lg" data-testid={`template-title-${template.id}`}>
                  {template.name}
                </CardTitle>
                <CardDescription data-testid={`template-description-${template.id}`}>
                  {template.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-xs">
                    {template.category}
                  </Badge>
                  <Button
                    size="sm"
                    onClick={() => onSelectTemplate(template)}
                    data-testid={`use-template-${template.id}`}
                  >
                    Use Template
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No templates found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}
