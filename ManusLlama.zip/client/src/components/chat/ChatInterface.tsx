import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Message, Task } from "@shared/schema";
import { MessageBubble } from "./MessageBubble";
import { ChatInput } from "./ChatInput";
import { TaskCard } from "./TaskCard";
import { TypingIndicator } from "../ui/loading";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

interface ChatMessage extends Message {
  task?: Task;
  steps?: string[];
}

export function ChatInterface() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // WebSocket for real-time task updates
  useWebSocket({
    onMessage: (data) => {
      if (data.type === 'task_update') {
        // Update task in existing messages
        setMessages(prev => prev.map(msg => {
          if (msg.task?.id === data.taskId) {
            return {
              ...msg,
              task: {
                ...msg.task,
                status: data.status,
                progress: data.progress,
              }
            };
          }
          return msg;
        }));
        
        // Invalidate tasks query to refresh sidebar
        queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
        
        if (data.status === 'completed') {
          toast({
            title: "Task Completed",
            description: "Your task has been completed successfully!",
          });
        } else if (data.status === 'failed') {
          toast({
            title: "Task Failed",
            description: "There was an error completing your task.",
            variant: "destructive",
          });
        }
      }
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ message, files }: { message: string; files?: File[] }) => {
      // TODO: Handle file uploads first
      if (files && files.length > 0) {
        const formData = new FormData();
        files.forEach(file => formData.append('files', file));
        
        const uploadResponse = await apiRequest('POST', '/api/upload', formData);
        // Handle file upload result
      }

      const response = await apiRequest('POST', '/api/chat', { message });
      return response.json();
    },
    onSuccess: (data) => {
      // Add user message
      const userMessage: ChatMessage = {
        id: data.message.id,
        userId: user?.id || '',
        taskId: data.message.taskId || null,
        role: 'user' as const,
        content: data.message.content,
        attachments: data.message.attachments || null,
        createdAt: data.message.createdAt || new Date(),
      };

      // Add AI response or task creation
      let aiMessage: ChatMessage;
      
      if (data.task) {
        aiMessage = {
          id: `ai-${Date.now()}`,
          userId: user?.id || '',
          taskId: data.task.id,
          role: 'assistant',
          content: `I'll ${data.task.type === 'analysis' ? 'analyze' : 'create'} that for you. This will involve several steps and I'll work on it autonomously.`,
          attachments: null,
          task: data.task,
          steps: data.steps || [],
          createdAt: new Date(),
        };
        
        toast({
          title: "Task Created",
          description: `Started working on: ${data.task.title}`,
        });
      } else {
        aiMessage = data.message;
      }

      setMessages(prev => {
        // Remove user message if it already exists (avoid duplicates)
        const withoutDuplicate = prev.filter(msg => 
          !(msg.role === 'user' && msg.content === userMessage.content)
        );
        return [...withoutDuplicate, userMessage, aiMessage];
      });
      
      setIsStreaming(false);
      queryClient.invalidateQueries({ queryKey: ['/api/user/credits'] });
    },
    onError: (error: Error) => {
      setIsStreaming(false);
      if (error.message.includes('402')) {
        toast({
          title: "Insufficient Credits",
          description: "You don't have enough credits for this task. Please upgrade your plan.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to send message. Please try again.",
          variant: "destructive",
        });
      }
    }
  });

  const handleSendMessage = (message: string, files?: File[]) => {
    if (!message.trim() && !files?.length) return;
    
    setIsStreaming(true);
    sendMessageMutation.mutate({ message, files });
  };

  const welcomeMessage: ChatMessage = {
    id: 'welcome',
    userId: 'system',
    taskId: null,
    role: 'assistant',
    content: "Hi! I'm powered by Llama 4 Maverick 17B-128E. I can help you with complex tasks, data analysis, content creation, and much more. What would you like me to work on today?",
    attachments: null,
    createdAt: new Date(),
  };

  const allMessages = messages.length === 0 ? [welcomeMessage] : messages;

  const suggestedPrompts = [
    "📊 Analyze Tesla's stock performance",
    "🌐 Build a personal portfolio website", 
    "📑 Create a business presentation",
    "🔍 Research latest AI trends"
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {allMessages.map((message) => (
          <div key={message.id}>
            <MessageBubble 
              message={message} 
              isStreaming={isStreaming && message === allMessages[allMessages.length - 1]}
            />
            
            {/* Show task card if message has associated task */}
            {message.task && (
              <div className="mt-4 ml-11">
                <TaskCard 
                  task={message.task} 
                  steps={message.steps}
                />
              </div>
            )}
            
            {/* Show suggestion buttons for welcome message */}
            {message.id === 'welcome' && messages.length === 0 && (
              <div className="mt-4 ml-11 flex flex-wrap gap-2">
                {suggestedPrompts.map((prompt) => (
                  <Button
                    key={prompt}
                    variant="outline"
                    size="sm"
                    onClick={() => handleSendMessage(prompt)}
                    className="text-sm"
                    data-testid={`suggestion-${prompt.split(' ').slice(-1)[0].toLowerCase()}`}
                  >
                    {prompt}
                  </Button>
                ))}
              </div>
            )}
          </div>
        ))}
        
        {/* Typing Indicator */}
        {isStreaming && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
              🤖
            </div>
            <div className="bg-card rounded-lg p-4">
              <TypingIndicator />
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <ChatInput
        onSendMessage={handleSendMessage}
        disabled={sendMessageMutation.isPending}
      />
    </div>
  );
}
