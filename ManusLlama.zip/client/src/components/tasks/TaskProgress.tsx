import { Task } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Clock, Loader2, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

interface TaskProgressProps {
  task: Task;
  onViewDetails?: (task: Task) => void;
}

export function TaskProgress({ task, onViewDetails }: TaskProgressProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'running':
        return <Loader2 className="w-4 h-4 text-yellow-500 animate-spin" />;
      default:
        return <Clock className="w-4 h-4 text-blue-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-600 dark:text-green-400';
      case 'failed':
        return 'bg-red-500/20 text-red-600 dark:text-red-400';
      case 'running':
        return 'bg-yellow-500/20 text-yellow-600 dark:text-yellow-400';
      default:
        return 'bg-blue-500/20 text-blue-600 dark:text-blue-400';
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <Card className="hover:shadow-md transition-shadow" data-testid={`task-card-${task.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-base truncate" data-testid={`task-title-${task.id}`}>
              {task.title}
            </CardTitle>
            {task.description && (
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {task.description}
              </p>
            )}
          </div>
          <Badge className={cn("ml-2 flex items-center space-x-1", getStatusColor(task.status || 'pending'))}>
            {getStatusIcon(task.status)}
            <span className="capitalize" data-testid={`task-status-${task.id}`}>
              {task.status}
            </span>
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Progress</span>
            <span data-testid={`task-progress-${task.id}`}>{task.progress}%</span>
          </div>
          <Progress value={task.progress} className="h-2" />
        </div>

        {/* Task Details */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Type:</span>
            <div className="font-medium capitalize">{task.type}</div>
          </div>
          <div>
            <span className="text-muted-foreground">Credits:</span>
            <div className="font-medium">{task.creditsUsed || 0}</div>
          </div>
        </div>

        {/* Timestamps */}
        <div className="text-xs text-muted-foreground space-y-1">
          <div>Created: {formatDate(task.createdAt!)}</div>
          {task.updatedAt && task.updatedAt !== task.createdAt && (
            <div>Updated: {formatDate(task.updatedAt)}</div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center space-x-2">
            {task.estimatedTime && (
              <Badge variant="outline" className="text-xs">
                ~{task.estimatedTime}min
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            {task.result && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onViewDetails?.(task)}
                data-testid={`view-result-${task.id}`}
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                View Result
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onViewDetails?.(task)}
              data-testid={`view-details-${task.id}`}
            >
              Details
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
