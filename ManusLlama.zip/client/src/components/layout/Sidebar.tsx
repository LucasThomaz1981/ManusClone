import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Brain, MessageCircle, CheckSquare, Layout, History, Settings, LogOut, ShieldCheck } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

export function Sidebar({ isOpen = true, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  const { data: credits } = useQuery({
    queryKey: ['/api/user/credits'],
    enabled: !!user,
  });

  const navigation = [
    { name: 'Chat', href: '/', icon: MessageCircle, current: location === '/' },
    { name: 'Tasks', href: '/tasks', icon: CheckSquare, current: location === '/tasks' },
    { name: 'Templates', href: '/templates', icon: Layout, current: location === '/templates' },
    { name: 'History', href: '/history', icon: History, current: location === '/history' },
    { name: 'Settings', href: '/settings', icon: Settings, current: location === '/settings' },
    { name: 'Bitcoin Recovery', href: '/bitcoin-recovery', icon: ShieldCheck, current: location === '/bitcoin-recovery' },
  ];

  const creditPercentage = user ? ((credits as any)?.credits || 0) / 2000 * 100 : 0;

  return (
    <div className={cn(
      "w-64 bg-card border-r border-border flex-shrink-0 flex flex-col",
      "lg:flex",
      isOpen ? "flex" : "hidden"
    )} data-testid="sidebar">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
            <Brain className="w-4 h-4 text-primary-foreground" />
          </div>
          <h1 className="text-xl font-bold">Manus AI</h1>
        </div>
        
        {/* User Credits */}
        {user && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Credits</span>
              <span className="text-sm font-medium" data-testid="user-credits">
                {(credits as any)?.credits || 0}
              </span>
            </div>
            <Progress value={creditPercentage} className="mt-2" />
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.name} href={item.href}>
              <a
                className={cn(
                  "flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors",
                  item.current
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-muted"
                )}
                data-testid={`nav-${item.name.toLowerCase()}`}
                onClick={() => onClose?.()}
              >
                <Icon className="w-5 h-5" />
                <span>{item.name}</span>
              </a>
            </Link>
          );
        })}
      </nav>

      {/* User Profile */}
      {user && (
        <div className="p-4 border-t border-border">
          <div className="flex items-center space-x-3">
            <Avatar className="w-8 h-8">
              <AvatarImage src={(user as any)?.profileImageUrl || undefined} />
              <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground">
                {(user as any)?.firstName?.[0] || (user as any)?.email?.[0] || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate" data-testid="user-name">
                {(user as any)?.firstName && (user as any)?.lastName 
                  ? `${(user as any)?.firstName} ${(user as any)?.lastName}`
                  : (user as any)?.email
                }
              </p>
              <p className="text-xs text-muted-foreground truncate" data-testid="user-plan">
                {(user as any)?.plan || 'Free'} Plan
              </p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.location.href = '/api/logout'}
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
