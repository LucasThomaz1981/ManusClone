import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, Sun, Moon, Bell } from "lucide-react";
import { cn } from "@/lib/utils";

interface TopBarProps {
  onToggleSidebar?: () => void;
  title?: string;
}

export function TopBar({ onToggleSidebar, title = "Chat with Llama 4 Maverick" }: TopBarProps) {
  const [isDark, setIsDark] = useState(true);

  const toggleTheme = () => {
    const html = document.documentElement;
    const newTheme = isDark ? 'light' : 'dark';
    html.className = newTheme;
    setIsDark(!isDark);
    localStorage.setItem('theme', newTheme);
  };

  return (
    <header className="h-16 bg-card border-b border-border flex items-center justify-between px-6" data-testid="topbar">
      <div className="flex items-center space-x-4">
        <Button
          variant="ghost"
          size="sm"
          className="lg:hidden"
          onClick={onToggleSidebar}
          data-testid="button-menu"
        >
          <Menu className="w-5 h-5" />
        </Button>
        <h2 className="text-lg font-semibold" data-testid="topbar-title">
          {title}
        </h2>
      </div>
      
      <div className="flex items-center space-x-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          data-testid="button-theme"
        >
          {isDark ? (
            <Sun className="w-5 h-5" />
          ) : (
            <Moon className="w-5 h-5" />
          )}
        </Button>
        <Button
          variant="ghost"
          size="sm"
          data-testid="button-notifications"
        >
          <Bell className="w-5 h-5" />
        </Button>
      </div>
    </header>
  );
}
