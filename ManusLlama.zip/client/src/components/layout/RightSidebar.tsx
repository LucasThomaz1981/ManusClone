import { useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Brain, TrendingUp, Globe, ChartPie, Search } from "lucide-react";

interface RightSidebarProps {
  className?: string;
}

export function RightSidebar({ className }: RightSidebarProps) {
  const { data: activeTasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
    select: (tasks) => tasks?.filter(task => 
      task.status === 'running' || task.status === 'pending'
    ).slice(0, 3) || [],
  });

  const templates = [
    {
      name: "Stock Analysis",
      description: "Research & analyze stocks",
      icon: TrendingUp,
      color: "from-blue-500 to-blue-600",
      prompt: "Analyze the stock performance of"
    },
    {
      name: "Website",
      description: "Build responsive sites",
      icon: Globe,
      color: "from-green-500 to-green-600",
      prompt: "Create a professional website for"
    },
    {
      name: "Slides",
      description: "Create presentations",
      icon: ChartPie,
      color: "from-purple-500 to-purple-600",
      prompt: "Create a presentation about"
    },
    {
      name: "Research",
      description: "Deep dive analysis",
      icon: Search,
      color: "from-orange-500 to-orange-600",
      prompt: "Research and analyze"
    }
  ];

  const handleTemplateClick = (prompt: string) => {
    // TODO: This should integrate with the chat input
    const chatInput = document.querySelector('[data-testid="chat-input"]') as HTMLTextAreaElement;
    if (chatInput) {
      chatInput.value = prompt + ' ';
      chatInput.focus();
    }
  };

  return (
    <div className={cn(
      "w-80 bg-card border-l border-border hidden xl:flex flex-col",
      className
    )} data-testid="right-sidebar">
      {/* Active Tasks */}
      <div className="p-6 border-b border-border">
        <h3 className="text-lg font-semibold mb-4">Active Tasks</h3>
        <div className="space-y-3">
          {activeTasks.length === 0 ? (
            <p className="text-sm text-muted-foreground">No active tasks</p>
          ) : (
            activeTasks.map((task) => (
              <div key={task.id} className="p-3 bg-muted/50 rounded-lg border border-border">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium truncate" data-testid={`active-task-${task.id}`}>
                    {task.title}
                  </h4>
                  <span className={cn(
                    "px-2 py-1 rounded text-xs",
                    task.status === 'running' 
                      ? 'bg-yellow-500/20 text-yellow-600 dark:text-yellow-400'
                      : 'bg-blue-500/20 text-blue-600 dark:text-blue-400'
                  )}>
                    {task.status === 'running' ? 'Running' : 'Queued'}
                  </span>
                </div>
                <Progress value={task.progress} className="mb-1" />
                <p className="text-xs text-muted-foreground">
                  {task.status === 'running' 
                    ? `${Math.max(1, Math.ceil((100 - (task.progress || 0)) / 20))} min remaining`
                    : 'Waiting to start'
                  }
                </p>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Quick Templates */}
      <div className="p-6 border-b border-border">
        <h3 className="text-lg font-semibold mb-4">Quick Templates</h3>
        <div className="grid grid-cols-2 gap-3">
          {templates.map((template) => {
            const Icon = template.icon;
            return (
              <Button
                key={template.name}
                variant="outline"
                className="p-3 h-auto flex flex-col items-start text-left space-y-2"
                onClick={() => handleTemplateClick(template.prompt)}
                data-testid={`template-${template.name.toLowerCase().replace(' ', '-')}`}
              >
                <div className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center bg-gradient-to-br text-white",
                  template.color
                )}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-medium">{template.name}</h4>
                  <p className="text-xs text-muted-foreground">{template.description}</p>
                </div>
              </Button>
            );
          })}
        </div>
      </div>

      {/* Model Info */}
      <div className="p-6 flex-1">
        <h3 className="text-lg font-semibold mb-4">Model Info</h3>
        <div className="space-y-4">
          <div className="p-4 bg-muted/50 rounded-lg border border-border">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h4 className="font-medium">Llama 4 Maverick</h4>
                <p className="text-sm text-muted-foreground">17B-128E Model</p>
              </div>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Context Length:</span>
                <span>1M tokens</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Multimodal:</span>
                <span className="text-green-500">✓ Yes</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Status:</span>
                <span className="text-green-500">● Online</span>
              </div>
            </div>
          </div>

          <div className="p-4 bg-muted/50 rounded-lg border border-border">
            <h4 className="font-medium mb-2">Today's Usage</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Messages:</span>
                <span data-testid="usage-messages">0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tasks:</span>
                <span data-testid="usage-tasks">0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Credits Used:</span>
                <span data-testid="usage-credits">0</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
