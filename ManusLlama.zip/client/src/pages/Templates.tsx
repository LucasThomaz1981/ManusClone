import { useState } from "react";
import { useLocation } from "wouter";
import { Template } from "@shared/schema";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { TemplateGallery } from "@/components/templates/TemplateGallery";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Layout } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Templates() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [templateInputs, setTemplateInputs] = useState<Record<string, string>>({});
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSelectTemplate = (template: Template) => {
    setSelectedTemplate(template);
    
    // Extract placeholders from prompt
    const placeholders = template.prompt.match(/\{([^}]+)\}/g) || [];
    const initialInputs: Record<string, string> = {};
    
    placeholders.forEach(placeholder => {
      const key = placeholder.slice(1, -1); // Remove { }
      initialInputs[key] = '';
    });
    
    setTemplateInputs(initialInputs);
  };

  const handleUseTemplate = () => {
    if (!selectedTemplate) return;
    
    // Validate required inputs
    const missingInputs = Object.entries(templateInputs).filter(([key, value]) => !value.trim());
    if (missingInputs.length > 0) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    // Replace placeholders in prompt with actual values
    let finalPrompt = selectedTemplate.prompt;
    Object.entries(templateInputs).forEach(([key, value]) => {
      finalPrompt = finalPrompt.replace(new RegExp(`\\{${key}\\}`, 'g'), value);
    });
    
    // Store the prompt and navigate to chat
    sessionStorage.setItem('templatePrompt', finalPrompt);
    
    toast({
      title: "Template Applied",
      description: "Redirecting to chat with your customized prompt.",
    });
    
    // Close dialog and navigate
    setSelectedTemplate(null);
    setLocation('/');
    
    // Trigger the prompt in chat (this will be handled by the chat interface)
    setTimeout(() => {
      const event = new CustomEvent('useTemplatePrompt', { detail: finalPrompt });
      window.dispatchEvent(event);
    }, 100);
  };

  const formatPlaceholder = (key: string) => {
    return key
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background" data-testid="templates-page">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 lg:relative lg:z-0 transition-transform duration-300",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <Sidebar 
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          title="Template Gallery"
        />

        <div className="flex-1 overflow-y-auto">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="p-6 pb-0">
              <div className="flex items-center space-x-3 mb-4">
                <Layout className="w-8 h-8 text-primary" />
                <div>
                  <h1 className="text-2xl font-bold">Template Gallery</h1>
                  <p className="text-muted-foreground">
                    Pre-built templates to jumpstart your tasks
                  </p>
                </div>
              </div>
            </div>

            {/* Template Gallery */}
            <TemplateGallery onSelectTemplate={handleSelectTemplate} />
          </div>
        </div>
      </div>

      {/* Template Customization Modal */}
      <Dialog open={!!selectedTemplate} onOpenChange={() => setSelectedTemplate(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedTemplate && (
            <>
              <DialogHeader>
                <DialogTitle data-testid="template-modal-title">
                  Customize {selectedTemplate.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedTemplate.description}
                  </p>
                </div>

                <div className="p-4 bg-muted rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Estimated Credits</span>
                    <span className="text-sm font-bold">{selectedTemplate.estimatedCredits}</span>
                  </div>
                </div>

                {Object.keys(templateInputs).length > 0 && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Required Information</h4>
                    {Object.entries(templateInputs).map(([key, value]) => (
                      <div key={key} className="space-y-2">
                        <Label htmlFor={key} className="text-sm font-medium">
                          {formatPlaceholder(key)} *
                        </Label>
                        {key.toLowerCase().includes('description') || 
                         key.toLowerCase().includes('detail') ||
                         key.toLowerCase().includes('content') ? (
                          <Textarea
                            id={key}
                            placeholder={`Enter ${formatPlaceholder(key).toLowerCase()}`}
                            value={value}
                            onChange={(e) => setTemplateInputs(prev => ({
                              ...prev,
                              [key]: e.target.value
                            }))}
                            className="min-h-[100px]"
                            data-testid={`input-${key.toLowerCase()}`}
                          />
                        ) : (
                          <Input
                            id={key}
                            placeholder={`Enter ${formatPlaceholder(key).toLowerCase()}`}
                            value={value}
                            onChange={(e) => setTemplateInputs(prev => ({
                              ...prev,
                              [key]: e.target.value
                            }))}
                            data-testid={`input-${key.toLowerCase()}`}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                )}

                <div className="space-y-2">
                  <h4 className="font-medium">Preview</h4>
                  <div className="p-3 bg-muted/50 rounded-lg text-sm">
                    {Object.keys(templateInputs).length > 0 ? (
                      (() => {
                        let preview = selectedTemplate.prompt;
                        Object.entries(templateInputs).forEach(([key, value]) => {
                          preview = preview.replace(
                            new RegExp(`\\{${key}\\}`, 'g'), 
                            value || `[${formatPlaceholder(key)}]`
                          );
                        });
                        return preview;
                      })()
                    ) : (
                      selectedTemplate.prompt
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-end space-x-3">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedTemplate(null)}
                    data-testid="button-cancel-template"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleUseTemplate}
                    disabled={Object.values(templateInputs).some(value => !value.trim())}
                    data-testid="button-use-template"
                  >
                    Use Template
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
