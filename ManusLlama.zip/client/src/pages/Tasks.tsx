import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Task } from "@shared/schema";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { TaskProgress } from "@/components/tasks/TaskProgress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Search, Filter, CheckSquare } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Tasks() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = !statusFilter || task.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = tasks.reduce((acc, task) => {
    const status = task.status || 'pending';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const statuses = [
    { key: 'pending', label: 'Pending', color: 'blue' },
    { key: 'running', label: 'Running', color: 'yellow' },
    { key: 'completed', label: 'Completed', color: 'green' },
    { key: 'failed', label: 'Failed', color: 'red' },
  ];

  const handleViewDetails = (task: Task) => {
    setSelectedTask(task);
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background" data-testid="tasks-page">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 lg:relative lg:z-0 transition-transform duration-300",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <Sidebar 
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          title="Task Management"
        />

        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <CheckSquare className="w-8 h-8 text-primary" />
                <div>
                  <h1 className="text-2xl font-bold">Tasks</h1>
                  <p className="text-muted-foreground">
                    {tasks.length} total tasks
                  </p>
                </div>
              </div>
            </div>

            {/* Status Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {statuses.map(status => (
                <div 
                  key={status.key}
                  className={cn(
                    "p-4 rounded-lg border cursor-pointer transition-colors",
                    statusFilter === status.key 
                      ? "bg-primary/10 border-primary" 
                      : "bg-card hover:bg-muted/50"
                  )}
                  onClick={() => setStatusFilter(statusFilter === status.key ? null : status.key)}
                  data-testid={`status-filter-${status.key}`}
                >
                  <div className="text-2xl font-bold">{statusCounts[status.key] || 0}</div>
                  <div className="text-sm text-muted-foreground">{status.label}</div>
                </div>
              ))}
            </div>

            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="search-tasks"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <div className="flex space-x-2">
                  {statusFilter && (
                    <Badge 
                      variant="secondary"
                      className="cursor-pointer"
                      onClick={() => setStatusFilter(null)}
                    >
                      {statuses.find(s => s.key === statusFilter)?.label} ×
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            {/* Tasks List */}
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredTasks.length === 0 ? (
              <div className="text-center py-12">
                <CheckSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No tasks found</h3>
                <p className="text-muted-foreground">
                  {tasks.length === 0 
                    ? "Start a conversation to create your first task"
                    : "Try adjusting your search or filters"
                  }
                </p>
              </div>
            ) : (
              <div className="grid gap-4">
                {filteredTasks.map((task) => (
                  <TaskProgress
                    key={task.id}
                    task={task}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Task Details Modal */}
      <Dialog open={!!selectedTask} onOpenChange={() => setSelectedTask(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedTask && (
            <>
              <DialogHeader>
                <DialogTitle data-testid="task-modal-title">
                  {selectedTask.title}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedTask.description || 'No description provided'}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Status:</span>
                    <div className="capitalize mt-1">{selectedTask.status}</div>
                  </div>
                  <div>
                    <span className="font-medium">Type:</span>
                    <div className="capitalize mt-1">{selectedTask.type}</div>
                  </div>
                  <div>
                    <span className="font-medium">Progress:</span>
                    <div className="mt-1">{selectedTask.progress}%</div>
                  </div>
                  <div>
                    <span className="font-medium">Credits Used:</span>
                    <div className="mt-1">{selectedTask.creditsUsed || 0}</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">Timeline</h4>
                  <div className="text-sm space-y-1">
                    <div>Created: {formatDate(selectedTask.createdAt!)}</div>
                    {selectedTask.updatedAt && selectedTask.updatedAt !== selectedTask.createdAt && (
                      <div>Updated: {formatDate(selectedTask.updatedAt)}</div>
                    )}
                  </div>
                </div>

                {selectedTask.result && (
                  <div>
                    <h4 className="font-medium mb-2">Result</h4>
                    <div className="p-4 bg-muted rounded-lg">
                      <pre className="whitespace-pre-wrap text-sm">
                        {typeof selectedTask.result === 'object' 
                          ? JSON.stringify(selectedTask.result, null, 2)
                          : selectedTask.result
                        }
                      </pre>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
