import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, MessageCircle, TrendingUp, Globe, ChartPie, Search, ArrowRight } from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: MessageCircle,
      title: "AI Chat Interface",
      description: "Powered by Llama 4 Maverick 17B-128E for intelligent conversations"
    },
    {
      icon: TrendingUp,
      title: "Stock Analysis",
      description: "Comprehensive financial analysis with charts and recommendations"
    },
    {
      icon: Globe,
      title: "Website Builder",
      description: "Create responsive, professional websites from simple prompts"
    },
    {
      icon: ChartPie,
      title: "Presentation Creator",
      description: "Generate compelling slide decks with data visualizations"
    },
    {
      icon: Search,
      title: "Research Assistant",
      description: "Deep dive analysis and competitive intelligence reports"
    },
    {
      icon: Brain,
      title: "Autonomous Tasks",
      description: "Let AI work independently while you focus on other priorities"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10" />
        
        <div className="relative max-w-7xl mx-auto px-6 pt-20 pb-16">
          <div className="text-center space-y-8">
            <div className="flex items-center justify-center space-x-3 mb-8">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-primary-foreground" />
              </div>
              <h1 className="text-4xl font-bold">Manus AI</h1>
            </div>
            
            <h2 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
              The 24/7 AI that<br />
              delivers results for you
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Powered by Llama 4 Maverick 17B-128E. Transform your thoughts into completed tasks with 
              autonomous AI that works while you sleep. From stock analysis to website creation, 
              Manus handles complex projects end-to-end.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-12">
              <Button 
                size="lg" 
                className="px-8 py-6 text-lg"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-get-started"
              >
                Get Started
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="px-8 py-6 text-lg"
                data-testid="button-learn-more"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h3 className="text-3xl font-bold mb-4">One simple prompt, big results</h3>
          <p className="text-xl text-muted-foreground">
            Leave it to Manus, watch the magic unfold
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow border-border/50">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Model Information */}
      <div className="bg-card/50 border-y border-border">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold mb-4">Powered by Llama 4 Maverick</h3>
            <p className="text-xl text-muted-foreground">
              State-of-the-art multimodal AI with 17B active parameters
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center space-y-3">
              <div className="text-3xl font-bold text-primary">1M</div>
              <div className="text-muted-foreground">Token Context</div>
            </div>
            <div className="text-center space-y-3">
              <div className="text-3xl font-bold text-primary">128E</div>
              <div className="text-muted-foreground">Expert Architecture</div>
            </div>
            <div className="text-center space-y-3">
              <div className="text-3xl font-bold text-primary">24/7</div>
              <div className="text-muted-foreground">Autonomous Operation</div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center space-y-8">
          <h3 className="text-4xl font-bold">Ready to transform your workflow?</h3>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join thousands of professionals who use Manus AI to automate complex tasks 
            and accelerate their productivity.
          </p>
          <Button 
            size="lg" 
            className="px-12 py-6 text-lg"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-start-free"
          >
            Start for Free
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
