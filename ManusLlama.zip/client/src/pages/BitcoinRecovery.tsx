import { useState } from "react";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Progress } from "@/components/ui/progress";
import { Loader2, ShieldCheck, Search, Database } from "lucide-react";

export default function BitcoinRecovery() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [content, setContent] = useState("");
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
  const { toast } = useToast();

  const recoveryMutation = useMutation({
    mutationFn: async (text: string) => {
      const res = await fetch("/api/bitcoin/recover", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text }),
      });
      if (!res.ok) throw new Error("Failed to start recovery");
      return res.json();
    },
    onSuccess: (data) => {
      setCurrentTaskId(data.taskId);
      toast({
        title: "Scan Started",
        description: "The Bitcoin recovery scan is now running in the background.",
      });
    },
  });

  const { data: taskStatus } = useQuery({
    queryKey: ["/api/tasks", currentTaskId],
    queryFn: async () => {
      const res = await fetch(`/api/tasks/${currentTaskId}`);
      return res.json();
    },
    enabled: !!currentTaskId,
    refetchInterval: (data) => (data?.status === "completed" || data?.status === "failed" ? false : 2000),
  });

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar onToggleSidebar={() => setIsSidebarOpen(true)} title="Bitcoin Asset Recovery" />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldCheck className="text-primary" />
                  Asset Recovery Engine
                </CardTitle>
                <CardDescription>
                  Paste logs, wallet exports, or raw text to scan for Bitcoin addresses and recover assets.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Paste your data here (WIF keys, addresses, or logs)..."
                  className="min-h-[200px] font-mono text-sm"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                />
                <Button 
                  onClick={() => recoveryMutation.mutate(content)}
                  disabled={recoveryMutation.isPending || !content}
                  className="w-full"
                >
                  {recoveryMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Search className="mr-2 h-4 w-4" />
                  )}
                  Start Recovery Scan
                </Button>
              </CardContent>
            </Card>

            {taskStatus && (
              <Card>
                <CardHeader>
                  <CardTitle>Scan Progress: {taskStatus.status}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Progress value={taskStatus.progress} />
                  
                  {taskStatus.status === "completed" && taskStatus.result && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                      <div className="p-4 border rounded-lg bg-muted/50">
                        <div className="text-sm text-muted-foreground">Addresses Scanned</div>
                        <div className="text-2xl font-bold">{taskStatus.result.addressesFound}</div>
                      </div>
                      <div className="p-4 border rounded-lg bg-primary/10 border-primary/20">
                        <div className="text-sm text-primary">With Balance</div>
                        <div className="text-2xl font-bold text-primary">{taskStatus.result.addressesWithBalance}</div>
                      </div>
                      <div className="p-4 border rounded-lg bg-muted/50">
                        <div className="text-sm text-muted-foreground">Total BTC Found</div>
                        <div className="text-2xl font-bold">{taskStatus.result.totalBalanceBTC} BTC</div>
                      </div>
                    </div>
                  )}

                  {taskStatus.result?.details?.length > 0 && (
                    <div className="mt-6">
                      <h4 className="font-semibold mb-2">Recovered Assets:</h4>
                      <div className="space-y-2">
                        {taskStatus.result.details.map((item: any, i: number) => (
                          <div key={i} className="flex justify-between p-3 border rounded bg-background">
                            <span className="font-mono text-sm">{item.address}</span>
                            <span className="font-bold text-green-600">{item.balance} BTC</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
