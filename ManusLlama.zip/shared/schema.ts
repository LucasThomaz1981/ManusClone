import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const addressTypeEnum = pgEnum("address_type", ["legacy", "segwit", "p2sh"]);
export const txStatusEnum = pgEnum("tx_status", ["pending", "confirmed", "failed"]);
export const auditActionEnum = pgEnum("audit_action", [
  "import_address",
  "export_key",
  "sign_transaction",
  "access_vault",
  "rotate_master_key",
  "backup_created",
  "backup_restored",
]);

// Session storage table.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  credits: integer("credits").default(1900),
  plan: varchar("plan").default("Free"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Bitcoin Addresses Table
export const bitcoinAddresses = pgTable("bitcoin_addresses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  address: varchar("address").notNull().unique(),
  addressType: addressTypeEnum("address_type").notNull(),
  publicKey: text("public_key").notNull(),
  encryptedPrivateKey: text("encrypted_private_key"), // AES-256-GCM encrypted
  balanceSat: integer("balance_sat").default(0).notNull(),
  lastBalanceUpdate: timestamp("last_balance_update"),
  isWatchOnly: boolean("is_watch_only").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Master Key Storage Table
export const masterKeys = pgTable("master_keys", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  encryptedMasterKey: text("encrypted_master_key").notNull(),
  publicKeyMaster: text("public_key_master").notNull(),
  mnemonicHash: varchar("mnemonic_hash").notNull(),
  keyDerivationSalt: varchar("key_derivation_salt").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Tasks table
export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  type: varchar("type").notNull(), // 'analysis', 'website', 'slides', 'research', 'bitcoin_recovery'
  status: varchar("status").default("pending"),
  progress: integer("progress").default(0),
  result: jsonb("result"),
  creditsUsed: integer("credits_used").default(0),
  estimatedTime: integer("estimated_time"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit Logs Table
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  action: auditActionEnum("action").notNull(),
  resourceType: varchar("resource_type"),
  resourceId: varchar("resource_id"),
  details: jsonb("details"),
  ipAddress: varchar("ip_address"),
  status: varchar("status").default("success"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  taskId: varchar("task_id").references(() => tasks.id),
  role: varchar("role").notNull(),
  content: text("content").notNull(),
  attachments: jsonb("attachments"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schemas and Types
export type User = typeof users.$inferSelect;
export type BitcoinAddress = typeof bitcoinAddresses.$inferSelect;
export type MasterKey = typeof masterKeys.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
export type Message = typeof messages.$inferSelect;

export const insertBitcoinAddressSchema = createInsertSchema(bitcoinAddresses).omit({ id: true, createdAt: true, updatedAt: true });
export const insertMasterKeySchema = createInsertSchema(masterKeys).omit({ id: true, createdAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true, updatedAt: true });
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
