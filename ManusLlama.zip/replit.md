# Overview

This is an AI chat application called "Manus AI" that provides intelligent conversations and autonomous task execution powered by Llama 4 Maverick 17B-128E. The application features a modern chat interface with real-time task management, template system, and credit-based usage tracking. Users can interact with the AI to perform various tasks like stock analysis, website building, presentation creation, and research.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using React with TypeScript and follows a modern component-based architecture:

- **UI Framework**: React 18 with TypeScript for type safety
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

The application uses a responsive layout with:
- Collapsible sidebar navigation with user credits display
- Main chat interface with message bubbles and task cards
- Right sidebar for quick templates and active task monitoring
- Dark/light theme support with CSS custom properties

## Backend Architecture

The backend follows a RESTful API design using Express.js with TypeScript:

- **Server Framework**: Express.js with TypeScript for API endpoints
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Real-time Communication**: WebSocket server for live task updates
- **File Upload**: Multer middleware for handling file attachments
- **Session Management**: Express sessions with PostgreSQL store

Key architectural patterns:
- **Service Layer**: Separated business logic (LlamaService, Storage) from route handlers
- **Middleware Architecture**: Layered middleware for authentication, logging, and error handling
- **Repository Pattern**: Database operations abstracted through storage interfaces

## Authentication System

Authentication is handled through Replit's OpenID Connect (OIDC) integration:

- **OAuth Provider**: Replit OIDC for seamless authentication within the Replit environment
- **Session Storage**: PostgreSQL-backed session store with configurable TTL
- **User Management**: Automatic user creation and profile synchronization
- **Authorization**: Route-level protection with middleware-based access control

The system maintains user profiles with credits, plan information, and usage tracking.

## Database Schema

PostgreSQL database with the following core entities:

- **Users**: Profile information, credits, plan details, creation timestamps
- **Tasks**: User-generated tasks with status tracking, progress monitoring, and result storage
- **Messages**: Chat history with role-based categorization and attachment support
- **Templates**: Predefined prompts for common use cases
- **Sessions**: Authentication session storage (required for Replit Auth)

The schema uses UUIDs for primary keys and includes proper foreign key relationships and indexing.

## Real-time Features

WebSocket integration provides live updates for:
- Task status changes and progress updates
- Real-time chat message streaming
- System notifications and alerts

The WebSocket server runs alongside the HTTP server and maintains connection state for active users.

# External Dependencies

## AI Service Integration

- **Together AI API**: Primary AI service using Llama 4 Maverick 17B-128E model
- **Model Configuration**: Configured for chat completions with customizable parameters (temperature, top_p, max_tokens)
- **Error Handling**: Robust error handling with fallback mechanisms
- **Usage Tracking**: Token usage monitoring for credit deduction

## Database Services

- **Neon Database**: Serverless PostgreSQL database with connection pooling
- **Connection Management**: WebSocket-compatible connection handling for serverless environments
- **Migration System**: Drizzle Kit for database schema migrations and management

## Development Tools

- **Replit Integration**: Custom plugins for development environment integration
- **Hot Reload**: Vite dev server with HMR for rapid development
- **Error Tracking**: Runtime error modal overlay for development debugging

## UI Components

- **Radix UI**: Headless UI components for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Consistent icon library throughout the application

## Build and Deployment

- **ESBuild**: Fast TypeScript compilation for production server bundle
- **Static Asset Serving**: Integrated static file serving for production deployment
- **Environment Configuration**: Environment-based configuration for development/production modes