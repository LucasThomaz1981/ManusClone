import { BitcoinService } from "./bitcoinService";

async function testRecovery() {
  const service = new BitcoinService();
  const testContent = `
    Some random text here.
    Found address: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa
    Another one: bc1q0sg9ed7xyrr4429m69p876yykyu6ed7xcp062e
    And a WIF key: 5Kb8kLf9zgWQand97C14zS3nQ7S1a1a1a1a1a1a1a1a1a1a1a1a
  `;

  console.log("Starting test recovery...");
  
  // Mocking storage and task status update for the test
  const mockUserId = "test-user";
  const mockTaskId = "test-task";
  
  // Regex extraction test
  const btcAddressRegex = /\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|\bbc1[ac-hj-np-z02-9]{11,71}\b/g;
  const addresses = Array.from(new Set(testContent.match(btcAddressRegex) || []));
  console.log("Addresses found:", addresses);

  if (addresses.length > 0) {
    console.log(`Checking balance for: ${addresses[0]}`);
    const balance = await service.getBalance(addresses[0]);
    console.log(`Balance: ${balance} BTC`);
  }

  console.log("Test completed.");
}

testRecovery().catch(console.error);
