import axios from "axios";
import { storage } from "./storage";
import { isValidPrivateKey, derivePublicKey, compressPublicKey } from "./crypto/ecdsa";
import { encryptPrivateKey } from "./crypto/vault";

const BLOCKSTREAM_API = "https://blockstream.info/api";

export class BitcoinService {
  /**
   * Consulta saldo de um endereço via Blockstream API
   */
  async getBalance(address: string): Promise<number> {
    try {
      const response = await axios.get(`${BLOCKSTREAM_API}/address/${address}`);
      const stats = response.data.chain_stats;
      return (stats.funded_txo_sum - stats.spent_txo_sum) / 100_000_000;
    } catch (error) {
      console.error(`Error fetching balance for ${address}:`, error);
      return 0;
    }
  }

  /**
   * Valida uma chave WIF e retorna informações do endereço
   */
  validateWIF(wif: string): boolean {
    // Implementação simplificada de validação WIF (checksum)
    // No ambiente real, usaria bibliotecas como bitcoinjs-lib
    return wif.length >= 51 && (wif.startsWith('5') || wif.startsWith('K') || wif.startsWith('L'));
  }

  /**
   * Processa a recuperação de ativos a partir de logs/texto
   */
  async processRecovery(userId: string, taskId: string, content: string) {
    try {
      await storage.updateTaskStatus(taskId, 'running', 10);
      
      // Extração de endereços (Regex)
      const btcAddressRegex = /\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b|\bbc1[ac-hj-np-z02-9]{11,71}\b/g;
      const addresses = Array.from(new Set(content.match(btcAddressRegex) || []));
      
      await storage.updateTaskStatus(taskId, 'running', 30);
      
      const results = [];
      let totalBalance = 0;

      for (let i = 0; i < addresses.length; i++) {
        const addr = addresses[i];
        const balance = await this.getBalance(addr);
        
        if (balance > 0) {
          totalBalance += balance;
          results.push({
            address: addr,
            balance,
            status: 'found'
          });
          
          // Registrar no banco se houver saldo
          // Nota: Aqui precisaríamos da chave privada para salvar como 'bitcoinAddress' completo
          // Por enquanto, salvamos como log de descoberta
        }
        
        const progress = 30 + Math.round(((i + 1) / addresses.length) * 60);
        await storage.updateTaskStatus(taskId, 'running', progress);
      }

      const finalResult = {
        addressesFound: addresses.length,
        addressesWithBalance: results.length,
        totalBalanceBTC: totalBalance,
        details: results
      };

      await storage.updateTaskResult(taskId, finalResult);
      
    } catch (error) {
      console.error("Recovery process error:", error);
      await storage.updateTaskStatus(taskId, 'failed', 0);
    }
  }
}

export const bitcoinService = new BitcoinService();
