import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { llamaService } from "./llamaService";
import { bitcoinService } from "./bitcoinService";
import { insertTaskSchema, insertMessageSchema } from "@shared/schema";

const upload = multer({
  dest: 'uploads/',
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Chat routes
  app.post('/api/chat', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { message, taskId } = req.body;

      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // Create user message
      const userMessage = await storage.createMessage({
        userId,
        taskId: taskId || null,
        role: 'user',
        content: message,
      });

      // Check if this requires task creation
      if (!taskId && (message.toLowerCase().includes('analyze') || 
                     message.toLowerCase().includes('create') ||
                     message.toLowerCase().includes('build') ||
                     message.toLowerCase().includes('research'))) {
        
        // Analyze the task
        const taskAnalysis = await llamaService.analyzeTask(message);
        
        // Check if user has enough credits
        const user = await storage.getUser(userId);
        if (!user || (user.credits || 0) < taskAnalysis.estimatedCredits) {
          return res.status(402).json({ 
            message: "Insufficient credits for this task",
            required: taskAnalysis.estimatedCredits,
            available: user?.credits || 0
          });
        }

        // Create task
        const task = await storage.createTask({
          userId,
          title: message.substring(0, 100),
          description: message,
          type: taskAnalysis.type,
          estimatedTime: taskAnalysis.estimatedTime,
          creditsUsed: taskAnalysis.estimatedCredits,
        });

        // Deduct credits
        await storage.deductCredits(userId, taskAnalysis.estimatedCredits);

        // Start task processing (async)
        processTaskAsync(task.id, message, taskAnalysis.steps);

        return res.json({
          message: userMessage,
          task: {
            id: task.id,
            title: task.title,
            type: task.type,
            status: task.status,
            estimatedTime: task.estimatedTime,
            steps: taskAnalysis.steps
          }
        });
      }

      // Regular chat response
      const response = await llamaService.chat([
        { role: 'system', content: 'You are Manus AI, powered by Llama 4 Maverick. You are helpful, autonomous, and can perform complex tasks.' },
        { role: 'user', content: message }
      ]);

      // Create AI response message
      const aiMessage = await storage.createMessage({
        userId,
        taskId: taskId || null,
        role: 'assistant',
        content: response.content,
      });

      // Deduct credits for regular chat
      const creditsUsed = llamaService.calculateCreditsUsed(response.usage);
      await storage.deductCredits(userId, creditsUsed);

      res.json({
        message: aiMessage,
        creditsUsed
      });

    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });

  // Task routes
  app.get('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tasks = await storage.getUserTasks(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get('/api/tasks/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const task = await storage.getTask(req.params.id);
      
      if (!task || task.userId !== userId) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      res.json(task);
    } catch (error) {
      console.error("Error fetching task:", error);
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  // Template routes
  app.get('/api/templates', async (req, res) => {
    try {
      const templates = await storage.getTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Messages routes
  app.get('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 50;
      const messages = await storage.getUserMessages(userId, limit);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // File upload routes
  app.post('/api/upload', isAuthenticated, upload.array('files'), (req: any, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      const fileUrls = files.map(file => ({
        filename: file.originalname,
        path: file.path,
        mimetype: file.mimetype,
        size: file.size,
      }));
      
      res.json({ files: fileUrls });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ message: "Failed to upload files" });
    }
  });

  // Bitcoin Recovery routes
  app.post('/api/bitcoin/recover', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { content } = req.body;

      if (!content) {
        return res.status(400).json({ message: "Content is required" });
      }

      const task = await storage.createTask({
        userId,
        title: "Bitcoin Asset Recovery Scan",
        description: "Scanning provided content for Bitcoin addresses and balances",
        type: 'bitcoin_recovery',
        estimatedTime: 5,
        creditsUsed: 100,
      });

      // Start async process
      bitcoinService.processRecovery(userId, task.id, content);

      res.json({ taskId: task.id });
    } catch (error) {
      console.error("Bitcoin recovery error:", error);
      res.status(500).json({ message: "Failed to start recovery process" });
    }
  });

  app.get('/api/bitcoin/balance/:address', async (req, res) => {
    try {
      const balance = await bitcoinService.getBalance(req.params.address);
      res.json({ address: req.params.address, balance });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch balance" });
    }
  });

  // User credits route
  app.get('/api/user/credits', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json({ credits: user?.credits || 0 });
    } catch (error) {
      console.error("Error fetching credits:", error);
      res.status(500).json({ message: "Failed to fetch credits" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time task updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket, req) => {
    console.log('WebSocket client connected');

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        // Handle WebSocket messages if needed
        console.log('WebSocket message:', message);
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  // Store WebSocket server for task updates
  (global as any).wss = wss;

  return httpServer;
}

// Async task processing function
async function processTaskAsync(taskId: string, description: string, steps: string[]) {
  try {
    // Update task to running
    await storage.updateTaskStatus(taskId, 'running', 10);
    broadcastTaskUpdate(taskId, 'running', 10);

    // Simulate task processing with steps
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate work
      const progress = Math.round(((i + 1) / steps.length) * 90);
      await storage.updateTaskStatus(taskId, 'running', progress);
      broadcastTaskUpdate(taskId, 'running', progress);
    }

    // Generate final result
    const response = await llamaService.chat([
      { role: 'system', content: 'You are completing an autonomous task. Provide a detailed, professional result.' },
      { role: 'user', content: `Complete this task: ${description}` }
    ]);

    const result = {
      content: response.content,
      completedAt: new Date().toISOString(),
      steps: steps.map((step, i) => ({ step, completed: true, order: i + 1 }))
    };

    await storage.updateTaskResult(taskId, result);
    broadcastTaskUpdate(taskId, 'completed', 100);

  } catch (error) {
    console.error('Task processing error:', error);
    await storage.updateTaskStatus(taskId, 'failed', 0);
    broadcastTaskUpdate(taskId, 'failed', 0);
  }
}

function broadcastTaskUpdate(taskId: string, status: string, progress: number) {
  const wss = (global as any).wss;
  if (!wss) return;

  const update = JSON.stringify({
    type: 'task_update',
    taskId,
    status,
    progress,
    timestamp: new Date().toISOString()
  });

  wss.clients.forEach((client: WebSocket) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(update);
    }
  });
}
