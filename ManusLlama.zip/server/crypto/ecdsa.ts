import { createPrivateKey, createPublicKey, randomBytes, sign, verify } from "crypto";
import { ec as EC } from "elliptic";

/**
 * ECDSA Cryptography Module
 * Implements secp256k1 curve operations for Bitcoin
 */

const ec = new EC("secp256k1");

/**
 * Generates a new ECDSA key pair using secp256k1 curve
 * @returns Object containing private and public keys in hex format
 */
export function generateKeyPair() {
  const keyPair = ec.genKeyPair();
  const privateKey = keyPair.getPrivate("hex");
  const publicKey = keyPair.getPublic("hex");

  return {
    privateKey,
    publicKey,
  };
}

/**
 * Derives a public key from a private key
 * @param privateKeyHex - Private key in hexadecimal format
 * @returns Public key in hexadecimal format
 */
export function derivePublicKey(privateKeyHex: string): string {
  const keyPair = ec.keyFromPrivate(privateKeyHex, "hex");
  return keyPair.getPublic("hex");
}

/**
 * Signs a message using ECDSA with DER encoding
 * @param message - Message to sign (hex string or Buffer)
 * @param privateKeyHex - Private key in hexadecimal format
 * @returns DER-encoded signature in hex format
 */
export function signMessage(message: string | Buffer, privateKeyHex: string): string {
  const messageBuffer = typeof message === "string" ? Buffer.from(message, "hex") : message;
  const keyPair = ec.keyFromPrivate(privateKeyHex, "hex");

  // Sign the message
  const signature = keyPair.sign(messageBuffer);

  // Convert to DER format
  const derSignature = signature.toDER("hex");
  return derSignature;
}

/**
 * Verifies a DER-encoded ECDSA signature
 * @param message - Original message (hex string or Buffer)
 * @param signature - DER-encoded signature in hex format
 * @param publicKeyHex - Public key in hexadecimal format
 * @returns True if signature is valid, false otherwise
 */
export function verifySignature(
  message: string | Buffer,
  signature: string,
  publicKeyHex: string
): boolean {
  try {
    const messageBuffer = typeof message === "string" ? Buffer.from(message, "hex") : message;
    const keyPair = ec.keyFromPublic(publicKeyHex, "hex");

    // Verify the signature
    return keyPair.verify(messageBuffer, signature);
  } catch {
    return false;
  }
}

/**
 * Generates a random 32-byte value for use as a nonce or salt
 * @returns Random bytes in hex format
 */
export function generateRandomBytes(length: number = 32): string {
  return randomBytes(length).toString("hex");
}

/**
 * Compresses a public key to its compressed form (33 bytes)
 * @param publicKeyHex - Uncompressed public key (65 bytes)
 * @returns Compressed public key (33 bytes)
 */
export function compressPublicKey(publicKeyHex: string): string {
  const keyPair = ec.keyFromPublic(publicKeyHex, "hex");
  return keyPair.getPublic(true, "hex");
}

/**
 * Decompresses a public key from its compressed form
 * @param compressedPublicKeyHex - Compressed public key (33 bytes)
 * @returns Uncompressed public key (65 bytes)
 */
export function decompressPublicKey(compressedPublicKeyHex: string): string {
  const keyPair = ec.keyFromPublic(compressedPublicKeyHex, "hex");
  return keyPair.getPublic(false, "hex");
}

/**
 * Validates if a given string is a valid ECDSA private key (secp256k1)
 * @param privateKeyHex - Private key in hexadecimal format
 * @returns True if valid, false otherwise
 */
export function isValidPrivateKey(privateKeyHex: string): boolean {
  try {
    const keyPair = ec.keyFromPrivate(privateKeyHex, "hex");
    return keyPair.validate().result;
  } catch {
    return false;
  }
}

/**
 * Validates if a given string is a valid public key (secp256k1)
 * @param publicKeyHex - Public key in hexadecimal format
 * @returns True if valid, false otherwise
 */
export function isValidPublicKey(publicKeyHex: string): boolean {
  try {
    const keyPair = ec.keyFromPublic(publicKeyHex, "hex");
    return keyPair.validate().result;
  } catch {
    return false;
  }
}
