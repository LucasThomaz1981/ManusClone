import { createCipheriv, createDecipheriv, randomBytes, hkdf as hkdfSync } from "crypto";

const hkdf = (hash: string, ikm: Buffer, salt: Buffer, info: string, length: number): Promise<Buffer> => {
  return new Promise((resolve, reject) => {
    hkdfSync(hash, ikm, salt, info, length, (err, derivedKey: ArrayBuffer) => {
      if (err) reject(err);
      else resolve(Buffer.from(derivedKey));
    });
  });
};

/**
 * Vault Encryption Module
 * Implements AES-256-GCM encryption for secure key storage
 */

const ALGORITHM = "aes-256-gcm";
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16; // 128 bits for GCM
const AUTH_TAG_LENGTH = 16; // 128 bits
const SALT_LENGTH = 16; // 128 bits

interface EncryptedData {
  ciphertext: string;
  iv: string;
  authTag: string;
  salt: string;
}

/**
 * Derives an encryption key from a master key using HKDF-SHA256
 * @param masterKey - Master key in hex format
 * @param salt - Salt for key derivation in hex format
 * @param info - Optional context string for key derivation
 * @returns Derived key in hex format
 */
export async function deriveEncryptionKey(
  masterKey: string,
  salt: string,
  info: string = "bitcoin-vault-encryption"
): Promise<string> {
  const masterKeyBuffer = Buffer.from(masterKey, "hex");
  const saltBuffer = Buffer.from(salt, "hex");

  const derivedKeyBuffer = await hkdf(
    "sha256",
    masterKeyBuffer,
    saltBuffer,
    info,
    KEY_LENGTH
  );

  return derivedKeyBuffer.toString("hex");
}

/**
 * Encrypts data using AES-256-GCM
 * @param plaintext - Data to encrypt (string or Buffer)
 * @param encryptionKey - Encryption key in hex format
 * @returns Encrypted data object with ciphertext, IV, and auth tag
 */
export function encryptData(plaintext: string | Buffer, encryptionKey: string): EncryptedData {
  const plaintextBuffer = typeof plaintext === "string" ? Buffer.from(plaintext, "utf-8") : plaintext;
  const keyBuffer = Buffer.from(encryptionKey, "hex");
  
  if (keyBuffer.length !== KEY_LENGTH) {
    throw new Error(`Invalid key length: expected ${KEY_LENGTH}, got ${keyBuffer.length}`);
  }

  // Generate random IV and salt
  const iv = randomBytes(IV_LENGTH);
  const salt = randomBytes(SALT_LENGTH);

  // Create cipher
  const cipher = createCipheriv(ALGORITHM, keyBuffer, iv);

  // Encrypt
  const ciphertext = Buffer.concat([cipher.update(plaintextBuffer), cipher.final()]);

  // Get authentication tag
  const authTag = cipher.getAuthTag();

  return {
    ciphertext: ciphertext.toString("hex"),
    iv: iv.toString("hex"),
    authTag: authTag.toString("hex"),
    salt: salt.toString("hex"),
  };
}

/**
 * Decrypts data encrypted with AES-256-GCM
 * @param encryptedData - Encrypted data object
 * @param encryptionKey - Encryption key in hex format
 * @returns Decrypted plaintext as string
 */
export function decryptData(encryptedData: EncryptedData, encryptionKey: string): string {
  const ciphertextBuffer = Buffer.from(encryptedData.ciphertext, "hex");
  const ivBuffer = Buffer.from(encryptedData.iv, "hex");
  const authTagBuffer = Buffer.from(encryptedData.authTag, "hex");
  const keyBuffer = Buffer.from(encryptionKey, "hex");

  // Create decipher
  const decipher = createDecipheriv(ALGORITHM, keyBuffer, ivBuffer);

  // Set authentication tag
  decipher.setAuthTag(authTagBuffer);

  // Decrypt
  try {
    const plaintext = Buffer.concat([decipher.update(ciphertextBuffer), decipher.final()]);
    return plaintext.toString("utf-8");
  } catch (error) {
    throw new Error("Decryption failed: authentication tag verification failed");
  }
}

/**
 * Encrypts a private key and stores it with metadata
 * @param privateKey - Private key in hex format
 * @param encryptionKey - Encryption key in hex format
 * @returns Encrypted private key object
 */
export function encryptPrivateKey(privateKey: string, encryptionKey: string): EncryptedData {
  return encryptData(privateKey, encryptionKey);
}

/**
 * Decrypts a stored encrypted private key
 * @param encryptedData - Encrypted private key object
 * @param encryptionKey - Encryption key in hex format
 * @returns Decrypted private key in hex format
 */
export function decryptPrivateKey(encryptedData: EncryptedData, encryptionKey: string): string {
  return decryptData(encryptedData, encryptionKey);
}

/**
 * Generates a random salt for key derivation
 * @returns Salt in hex format
 */
export function generateSalt(): string {
  return randomBytes(SALT_LENGTH).toString("hex");
}

/**
 * Converts encrypted data object to JSON string for storage
 * @param encryptedData - Encrypted data object
 * @returns JSON string representation
 */
export function encryptedDataToJSON(encryptedData: EncryptedData): string {
  return JSON.stringify(encryptedData);
}

/**
 * Converts JSON string back to encrypted data object
 * @param json - JSON string representation
 * @returns Encrypted data object
 */
export function jsonToEncryptedData(json: string): EncryptedData {
  const parsed = JSON.parse(json);
  return {
    ciphertext: parsed.ciphertext,
    iv: parsed.iv,
    authTag: parsed.authTag,
    salt: parsed.salt,
  };
}
