import Together from 'together-ai';

const together = new Together({
  apiKey: process.env.TOGETHER_API_KEY || process.env.LLAMA_API_KEY || 'default_key',
});

export interface LlamaResponse {
  content: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export class LlamaService {
  private readonly model = 'meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8';

  async chat(messages: ChatMessage[]): Promise<LlamaResponse> {
    try {
      const response = await together.chat.completions.create({
        model: this.model,
        messages,
        max_tokens: 2048,
        temperature: 0.7,
        top_p: 0.9,
        stream: false,
      });

      const choice = response.choices[0];
      if (!choice || !choice.message) {
        throw new Error('Invalid response from Llama API');
      }

      return {
        content: choice.message.content || '',
        usage: response.usage ? {
          promptTokens: response.usage.prompt_tokens,
          completionTokens: response.usage.completion_tokens,
          totalTokens: response.usage.total_tokens,
        } : undefined,
      };
    } catch (error) {
      console.error('Llama API error:', error);
      throw new Error('Failed to generate response from Llama 4 Maverick');
    }
  }

  async streamChat(messages: ChatMessage[]): Promise<AsyncIterable<string>> {
    try {
      const response = await together.chat.completions.create({
        model: this.model,
        messages,
        max_tokens: 2048,
        temperature: 0.7,
        top_p: 0.9,
        stream: true,
      });

      const streamGenerator = async function* () {
        for await (const chunk of response) {
          const choice = chunk.choices[0];
          if (choice && choice.delta && choice.delta.content) {
            yield choice.delta.content;
          }
        }
      };

      return streamGenerator();
    } catch (error) {
      console.error('Llama streaming error:', error);
      throw new Error('Failed to stream response from Llama 4 Maverick');
    }
  }

  async analyzeTask(taskDescription: string): Promise<{
    type: string;
    estimatedTime: number;
    estimatedCredits: number;
    steps: string[];
  }> {
    const analysisPrompt = `Analyze this task request and provide structured information:

Task: "${taskDescription}"

Please respond with a JSON object containing:
- type: one of "analysis", "website", "slides", "research", "content", "automation"
- estimatedTime: time in minutes
- estimatedCredits: credit cost estimate
- steps: array of step descriptions

Focus on being realistic about time and costs.`;

    try {
      const response = await this.chat([
        { role: 'system', content: 'You are a task analysis expert. Always respond with valid JSON only.' },
        { role: 'user', content: analysisPrompt }
      ]);

      const analysis = JSON.parse(response.content);
      return {
        type: analysis.type || 'content',
        estimatedTime: analysis.estimatedTime || 5,
        estimatedCredits: analysis.estimatedCredits || 50,
        steps: analysis.steps || ['Processing request', 'Generating content', 'Finalizing output']
      };
    } catch (error) {
      console.error('Task analysis error:', error);
      // Return default analysis if parsing fails
      return {
        type: 'content',
        estimatedTime: 5,
        estimatedCredits: 50,
        steps: ['Processing request', 'Analyzing content', 'Generating response']
      };
    }
  }

  calculateCreditsUsed(usage?: LlamaResponse['usage']): number {
    if (!usage) return 10;
    
    // Rough calculation based on token usage
    const inputCost = Math.ceil(usage.promptTokens / 1000) * 1;
    const outputCost = Math.ceil(usage.completionTokens / 1000) * 3;
    return Math.max(inputCost + outputCost, 5);
  }
}

export const llamaService = new LlamaService();
