import { Message } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Brain, User } from "lucide-react";

interface MessageBubbleProps {
  message: Message;
  isStreaming?: boolean;
}

export function MessageBubble({ message, isStreaming = false }: MessageBubbleProps) {
  const isUser = message.role === 'user';
  
  return (
    <div className={cn(
      "flex items-start space-x-3 fade-in",
      isUser ? "justify-end" : "justify-start"
    )}>
      {!isUser && (
        <Avatar className="w-8 h-8 bg-gradient-to-br from-primary to-accent">
          <AvatarFallback>
            <Brain className="w-4 h-4 text-primary-foreground" />
          </AvatarFallback>
        </Avatar>
      )}
      
      <div className={cn(
        "max-w-3xl rounded-lg p-4",
        isUser 
          ? "bg-primary text-primary-foreground" 
          : "bg-card border border-border"
      )}>
        <div className="whitespace-pre-wrap">
          {message.content}
          {isStreaming && (
            <span className="inline-block w-2 h-5 ml-1 bg-current animate-pulse" />
          )}
        </div>
        
        {message.attachments && Array.isArray(message.attachments) && message.attachments.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {(message.attachments as any[]).map((attachment: any, index: number) => (
              <div key={index} className="px-2 py-1 bg-muted/50 rounded text-xs">
                📎 {attachment.filename || 'File'}
              </div>
            ))}
          </div>
        ) as React.ReactNode}
      </div>
      
      {isUser && (
        <Avatar className="w-8 h-8 bg-gradient-to-br from-secondary to-muted">
          <AvatarFallback>
            <User className="w-4 h-4 text-secondary-foreground" />
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}
