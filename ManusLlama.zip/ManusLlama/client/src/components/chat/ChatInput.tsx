import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Paperclip, Send, Image, Mic, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  onSendMessage: (message: string, files?: File[]) => void;
  disabled?: boolean;
  placeholder?: string;
}

export function ChatInput({ 
  onSendMessage, 
  disabled = false,
  placeholder = "Ask me anything or describe a task you'd like me to complete..." 
}: ChatInputProps) {
  const [message, setMessage] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = useCallback(() => {
    const trimmedMessage = message.trim();
    if (!trimmedMessage && files.length === 0) return;
    
    onSendMessage(trimmedMessage, files);
    setMessage("");
    setFiles([]);
    
    // Reset textarea height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  }, [message, files, onSendMessage]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    setFiles(prev => [...prev, ...selectedFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="p-6 border-t border-border bg-card">
      <div className="max-w-4xl mx-auto">
        {files.length > 0 && (
          <div className="mb-4 flex flex-wrap gap-2">
            {files.map((file, index) => (
              <div key={index} className="flex items-center space-x-2 bg-muted px-3 py-2 rounded-lg">
                <FileText className="w-4 h-4" />
                <span className="text-sm truncate max-w-32">{file.name}</span>
                <button
                  onClick={() => removeFile(index)}
                  className="text-muted-foreground hover:text-foreground"
                  data-testid={`remove-file-${index}`}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
        
        <div className="relative">
          <div className="flex items-end space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Textarea
                  ref={textareaRef}
                  value={message}
                  onChange={handleTextareaChange}
                  onKeyDown={handleKeyDown}
                  placeholder={placeholder}
                  disabled={disabled}
                  className="min-h-[60px] max-h-[200px] pr-12 resize-none"
                  data-testid="chat-input"
                />
                <button
                  onClick={openFileDialog}
                  className="absolute right-3 bottom-3 p-2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="button-attach"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
              </div>
              
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <button 
                    className="flex items-center space-x-1 hover:text-foreground transition-colors"
                    data-testid="button-image"
                  >
                    <Image className="w-4 h-4" />
                    <span>Image</span>
                  </button>
                  <button 
                    onClick={openFileDialog}
                    className="flex items-center space-x-1 hover:text-foreground transition-colors"
                    data-testid="button-file"
                  >
                    <FileText className="w-4 h-4" />
                    <span>File</span>
                  </button>
                  <button 
                    className="flex items-center space-x-1 hover:text-foreground transition-colors"
                    data-testid="button-voice"
                  >
                    <Mic className="w-4 h-4" />
                    <span>Voice</span>
                  </button>
                </div>
                <div className="text-xs text-muted-foreground">
                  {navigator.platform.includes('Mac') ? '⌘' : 'Ctrl'} + Enter to send
                </div>
              </div>
            </div>
            
            <Button
              onClick={handleSend}
              disabled={disabled || (!message.trim() && files.length === 0)}
              className="p-3 shrink-0"
              data-testid="button-send"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*,.pdf,.doc,.docx,.txt,.csv,.json"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}
