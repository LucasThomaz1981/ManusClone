import { Task } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Clock, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface TaskCardProps {
  task: Task;
  steps?: string[];
  className?: string;
}

export function TaskCard({ task, steps = [], className }: TaskCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-500';
      case 'failed':
        return 'text-red-500';
      case 'running':
        return 'text-yellow-500';
      default:
        return 'text-blue-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'running':
        return <Loader2 className="w-4 h-4 text-yellow-500 animate-spin" />;
      default:
        return <Clock className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className={cn(
      "bg-muted/50 rounded-lg p-4 border border-border",
      className
    )}>
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-medium truncate" data-testid={`task-title-${task.id}`}>
          {task.title}
        </h4>
        <div className={cn(
          "px-2 py-1 rounded text-xs font-medium flex items-center space-x-1",
          task.status === 'completed' ? 'bg-green-500/20 text-green-600 dark:text-green-400' :
          task.status === 'failed' ? 'bg-red-500/20 text-red-600 dark:text-red-400' :
          task.status === 'running' ? 'bg-yellow-500/20 text-yellow-600 dark:text-yellow-400' :
          'bg-blue-500/20 text-blue-600 dark:text-blue-400'
        )}>
          {getStatusIcon(task.status || 'pending')}
          <span data-testid={`task-status-${task.id}`}>
            {(task.status || 'pending').charAt(0).toUpperCase() + (task.status || 'pending').slice(1)}
          </span>
        </div>
      </div>
      
      {task.description && (
        <p className="text-sm text-muted-foreground mb-3">{task.description}</p>
      )}
      
      {steps.length > 0 && (
        <div className="space-y-2 text-sm mb-4">
          {steps.map((step, index) => {
            const progress = task.progress || 0;
            const isCompleted = progress > (index / steps.length) * 100;
            const isCurrent = progress >= (index / steps.length) * 100 && 
                             progress < ((index + 1) / steps.length) * 100;
            
            return (
              <div key={index} className="flex items-center space-x-2">
                {isCompleted ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : isCurrent ? (
                  <Loader2 className="w-4 h-4 text-primary animate-spin" />
                ) : (
                  <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />
                )}
                <span className={cn(
                  isCompleted ? 'text-foreground' : 
                  isCurrent ? 'text-primary' : 'text-muted-foreground/60'
                )}>
                  {step}
                </span>
              </div>
            );
          })}
        </div>
      )}
      
      <Progress value={task.progress} className="mb-3" />
      
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span data-testid={`task-progress-${task.id}`}>
          {task.progress || 0}% complete
        </span>
        {task.estimatedTime && (
          <span>
            Estimated: {task.estimatedTime} min
          </span>
        )}
      </div>
    </div>
  );
}
