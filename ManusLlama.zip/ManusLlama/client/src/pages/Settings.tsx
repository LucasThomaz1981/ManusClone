import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sidebar } from "@/components/layout/Sidebar";
import { TopBar } from "@/components/layout/TopBar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { 
  Settings as SettingsIcon, 
  User, 
  CreditCard, 
  Bell, 
  Shield, 
  Moon, 
  Sun, 
  Palette,
  Download,
  Trash2,
  ExternalLink
} from "lucide-react";

export default function Settings() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(
    typeof window !== 'undefined' ? document.documentElement.classList.contains('dark') : true
  );
  const [notifications, setNotifications] = useState({
    taskCompletion: true,
    systemUpdates: false,
    creditAlerts: true,
    weeklyReport: false,
  });

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: credits } = useQuery({
    queryKey: ['/api/user/credits'],
    enabled: !!user,
  });

  const handleThemeToggle = () => {
    const html = document.documentElement;
    const newTheme = isDarkMode ? 'light' : 'dark';
    html.className = newTheme;
    setIsDarkMode(!isDarkMode);
    localStorage.setItem('theme', newTheme);
    
    toast({
      title: "Theme Updated",
      description: `Switched to ${newTheme} mode.`,
    });
  };

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications(prev => ({
      ...prev,
      [key]: value
    }));
    
    toast({
      title: "Notification Preferences Updated",
      description: "Your notification settings have been saved.",
    });
  };

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  const handleDeleteAccount = () => {
    // This would typically show a confirmation dialog
    toast({
      title: "Account Deletion",
      description: "This feature will be available soon. Contact support for assistance.",
      variant: "destructive",
    });
  };

  const creditPercentage = user && credits ? ((credits as any).credits / 2000) * 100 : 0;

  const planFeatures = {
    Free: [
      "300 daily refresh credits",
      "Basic chat access",
      "1 concurrent task",
      "Community support"
    ],
    Basic: [
      "1,900 monthly credits",
      "Advanced models",
      "2 concurrent tasks",
      "Image generation",
      "Priority support"
    ],
    Plus: [
      "3,900 monthly credits", 
      "All Basic features",
      "3 concurrent tasks",
      "Video generation",
      "Premium support"
    ],
    Pro: [
      "19,900 monthly credits",
      "All Plus features", 
      "10 concurrent tasks",
      "Early access features",
      "Dedicated support"
    ]
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background" data-testid="settings-page">
      {/* Mobile sidebar backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 lg:relative lg:z-0 transition-transform duration-300",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <Sidebar 
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          title="Settings"
        />

        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Header */}
            <div className="flex items-center space-x-3">
              <SettingsIcon className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Settings</h1>
                <p className="text-muted-foreground">
                  Manage your account preferences and configuration
                </p>
              </div>
            </div>

            {/* Profile Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="w-5 h-5" />
                  <span>Profile</span>
                </CardTitle>
                <CardDescription>
                  Your account information and preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {user && (
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={(user as any)?.profileImageUrl || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-primary to-accent text-primary-foreground text-lg">
                        {(user as any)?.firstName?.[0] || (user as any)?.email?.[0] || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-1">
                      <h3 className="text-lg font-medium" data-testid="profile-name">
                        {(user as any)?.firstName && (user as any)?.lastName 
                          ? `${(user as any)?.firstName} ${(user as any)?.lastName}`
                          : (user as any)?.email
                        }
                      </h3>
                      <p className="text-sm text-muted-foreground" data-testid="profile-email">
                        {(user as any)?.email}
                      </p>
                      <Badge variant="outline" data-testid="profile-plan">
                        {(user as any)?.plan || 'Free'} Plan
                      </Badge>
                    </div>
                  </div>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input 
                      id="firstName" 
                      defaultValue={(user as any)?.firstName || ""} 
                      data-testid="input-firstname"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input 
                      id="lastName" 
                      defaultValue={(user as any)?.lastName || ""} 
                      data-testid="input-lastname"
                    />
                  </div>
                </div>
                
                <Button variant="outline" disabled data-testid="button-save-profile">
                  Save Changes
                </Button>
              </CardContent>
            </Card>

            {/* Subscription & Credits */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="w-5 h-5" />
                  <span>Subscription & Credits</span>
                </CardTitle>
                <CardDescription>
                  Manage your plan and credit usage
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Current Plan */}
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">Current Plan</h4>
                    <Badge className="bg-gradient-to-r from-primary to-accent text-primary-foreground">
                      {(user as any)?.plan || 'Free'}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    {planFeatures[(user as any)?.plan as keyof typeof planFeatures || 'Free']?.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Credit Usage */}
                {credits && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Credit Balance</span>
                      <span className="text-lg font-bold" data-testid="credits-balance">
                        {(credits as any).credits}
                      </span>
                    </div>
                    <Progress value={creditPercentage} className="h-2" />
                    <p className="text-xs text-muted-foreground">
                      {Math.round(creditPercentage)}% of monthly credits used
                    </p>
                  </div>
                )}

                <div className="flex space-x-3">
                  <Button disabled data-testid="button-upgrade-plan">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Upgrade Plan
                  </Button>
                  <Button variant="outline" disabled data-testid="button-billing-history">
                    Billing History
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Appearance Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Palette className="w-5 h-5" />
                  <span>Appearance</span>
                </CardTitle>
                <CardDescription>
                  Customize the look and feel of your interface
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-2">
                      {isDarkMode ? (
                        <Moon className="w-4 h-4" />
                      ) : (
                        <Sun className="w-4 h-4" />
                      )}
                      <Label>Dark Mode</Label>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Toggle between light and dark themes
                    </p>
                  </div>
                  <Switch
                    checked={isDarkMode}
                    onCheckedChange={handleThemeToggle}
                    data-testid="switch-dark-mode"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Bell className="w-5 h-5" />
                  <span>Notifications</span>
                </CardTitle>
                <CardDescription>
                  Choose what notifications you want to receive
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(notifications).map(([key, value]) => (
                  <div key={key} className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        {key === 'taskCompletion' && 'Get notified when your tasks are completed'}
                        {key === 'systemUpdates' && 'Receive updates about new features and improvements'}
                        {key === 'creditAlerts' && 'Alerts when your credits are running low'}
                        {key === 'weeklyReport' && 'Weekly summary of your usage and tasks'}
                      </p>
                    </div>
                    <Switch
                      checked={value}
                      onCheckedChange={(checked) => handleNotificationChange(key, checked)}
                      data-testid={`switch-${key}`}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Security Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="w-5 h-5" />
                  <span>Security</span>
                </CardTitle>
                <CardDescription>
                  Manage your account security and privacy
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Button variant="outline" disabled data-testid="button-change-password">
                    Change Password
                  </Button>
                  <Button variant="outline" disabled data-testid="button-two-factor">
                    Enable Two-Factor Authentication
                  </Button>
                  <Button variant="outline" disabled data-testid="button-download-data">
                    <Download className="w-4 h-4 mr-2" />
                    Download My Data
                  </Button>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-destructive">Danger Zone</h4>
                  <div className="flex space-x-3">
                    <Button 
                      variant="outline" 
                      onClick={handleLogout}
                      data-testid="button-logout"
                    >
                      Sign Out
                    </Button>
                    <Button 
                      variant="destructive" 
                      onClick={handleDeleteAccount}
                      data-testid="button-delete-account"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Account
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
