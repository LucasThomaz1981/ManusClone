# Manus AI - Bitcoin Asset Recovery Edition

Esta é uma versão especializada do ManusClone, integrada com um motor de recuperação de ativos Bitcoin de alta performance.

## 🚀 Funcionalidades Integradas

### 1. Motor de Recuperação (Recovery Engine)
- **Extração Inteligente:** Parser via Regex para endereços Legacy (1...), SegWit (bc1...), P2SH (3...) e chaves WIF.
- **Suporte Electrum:** Processamento de arquivos de carteira Electrum com suporte a senhas padrão (`Benjamin2020*1981$`).
- **Validação em Tempo Real:** Integração com a API Blockstream.info para verificação de saldos em Mainnet.
- **Busca por Padrão Binário:** Filtros avançados para chaves privadas baseados em padrões de bits fornecidos pelo usuário.

### 2. Segurança Criptográfica
- **ECDSA (secp256k1):** Implementação completa da curva elíptica do Bitcoin para geração e validação de chaves.
- **Vault AES-256-GCM:** Armazenamento seguro de chaves recuperadas com criptografia de nível militar.
- **Master Key System:** Sistema de derivação de chaves baseado em HKDF-SHA256.

### 3. Interface do Usuário
- **Dashboard de Recuperação:** Interface intuitiva para colagem de logs e monitoramento de progresso.
- **Task Management:** Sistema de tarefas assíncronas que permite rodar scans pesados em segundo plano.
- **Audit Logs:** Registro completo de todas as operações críticas para segurança.

## 🛠️ Tecnologias Utilizadas
- **Frontend:** React, TypeScript, Tailwind CSS, Lucide Icons, Radix UI.
- **Backend:** Node.js, Express, WebSocket (WS), Axios.
- **Banco de Dados:** PostgreSQL (Drizzle ORM).
- **Criptografia:** Elliptic, Node.js Crypto.

## 📦 Como Rodar
1. Instale as dependências: `npm install`
2. Configure o banco de dados via Drizzle.
3. Inicie o servidor: `npm run dev`

---
*Desenvolvido para recuperação ética de ativos e pesquisa de segurança em blockchain.*
